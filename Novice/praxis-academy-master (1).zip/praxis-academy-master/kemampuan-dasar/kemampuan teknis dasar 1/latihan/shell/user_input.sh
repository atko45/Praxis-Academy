#!/bin/bash
echo "Enter Your Name"
read name
echo "Welcome $name to LinuxHint"
