#!/bin/bash

# Add two numeric value
((sum=25+35))

#Print the result
echo $sum
