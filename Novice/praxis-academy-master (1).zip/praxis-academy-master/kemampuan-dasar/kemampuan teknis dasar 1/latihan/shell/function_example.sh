#!/bin/bash
function F1()
{
echo 'Yeah! I like bash programming'
}

F1
