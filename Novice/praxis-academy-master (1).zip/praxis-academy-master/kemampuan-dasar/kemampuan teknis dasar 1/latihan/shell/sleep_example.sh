#!/bin/bash

echo “Wait for 100 seconds”
sleep 100
echo “Completed”
