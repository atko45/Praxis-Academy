Django ModelForm

-Buat forms.py
    - import ModelForm
    - import model yang dibuat (model Task)
    - definisikan form menggunakan class
    
-Di Views
    - import form
    - buat variable yang isinya form (yang sudah dibuat)
    - kirim ke template

-Di template
    - memasang form sesuai nama yang dikirim dari views
    
    
