						CRUD

~Penjualan
	-Date Transaction
	-Barang 
	-Quantity
	-Harga

~Lain-lain
	-Tanggal
	-Keterangan
	-Kas
	-Piutang
	-Catatan
	