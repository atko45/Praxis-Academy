from django.apps import AppConfig


class KasConfig(AppConfig):
    name = 'kas'
