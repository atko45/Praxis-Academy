from django.apps import AppConfig


class LainConfig(AppConfig):
    name = 'lain'
