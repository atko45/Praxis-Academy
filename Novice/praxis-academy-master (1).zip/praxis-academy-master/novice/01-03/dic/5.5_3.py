y = {x: x**2 for x in (2, 4, 6)}

print(y)