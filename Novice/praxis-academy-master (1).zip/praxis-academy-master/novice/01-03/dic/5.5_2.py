dict = {'Name': 'GIl', 'Age': 7, 'Class': 'First'}
print (dict['Name'])