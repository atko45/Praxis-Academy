Just a day for presentation
