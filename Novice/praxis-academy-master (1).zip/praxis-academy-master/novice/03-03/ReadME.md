Django PG:

1. Start PG server
2. atur koneksi ke PG di file setting.py
3. install driver dengan "python -m pip install psycopg2"
4. jalankan migrasi dengan "python manage.py migrate"
5. jalankan aplikasi "python manage.py runserver"