class Person:
    def say_hi(self):
        print('Hallo, How r u?')

p = Person()
p.say_hi()