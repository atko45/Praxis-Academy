words = ['cat', 'window', 'defenestrate']
for w in words:
    print(w, len(w))

