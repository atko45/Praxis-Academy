class MyEmptyClass:
    pass