def initlog(*args):
    pass 