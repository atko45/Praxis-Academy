a = input("Enter your first num :")
b = input("Enter your second num :")

if b > a:
  pass