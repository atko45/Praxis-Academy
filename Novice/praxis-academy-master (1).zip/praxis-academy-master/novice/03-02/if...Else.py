a = int(input("Enter your first num :"))
b = int(input("Enter your second num :"))

if b > a:
  print("b is greater than a")
