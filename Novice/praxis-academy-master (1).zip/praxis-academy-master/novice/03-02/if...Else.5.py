a = int(input("Enter your first num :"))
b = int(input("Enter your second num :"))

if a > b: print("a is greater than b")