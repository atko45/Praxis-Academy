a = int(input("Enter your first num :"))
b = int(input("Enter your second num :"))

print("A") if a > b else print("B") 