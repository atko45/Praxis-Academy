a = int(input("Enter your first num :"))
b = int(input("Enter your second num :"))
c = int(input("Enter your third num :"))

if a > b or a > c:
  print("At least one of the conditions is True")