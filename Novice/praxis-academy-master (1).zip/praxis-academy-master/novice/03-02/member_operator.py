a = input("Enter your first argumen :")
b = input("Enter your second argumen :")
x = [a, b]

print("banana" in x)
print("pineapple" not in x)