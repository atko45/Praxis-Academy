a = int(input("Enter your first num :"))
b = int(input("Enter your second num :"))
c = int(input("Enter your third num :"))

if a > b and c > a:
  print("Both conditions are True")
  