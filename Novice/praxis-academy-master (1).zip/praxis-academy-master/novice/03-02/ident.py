x = ["jeruk", "mangga"]
y = ["mangga", "jeruk"]
z = x

print(x is z)
print(x is y)
print(x == y)

print(x is not z)
print(x is not y)
print(x != y)


a = input("Enter first :")
b = input("Enter second :")
c = input("Enter third :")
d = input("Enter forth :")
x = [a, b]
y = [c, d]
z = x

print(x is z)
print(x is y)
print(x == y)

print(x is not z)
print(x is not y)
print(x != y)
